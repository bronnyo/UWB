import java.util.*;
/**
 * ReportDriver is a class that contains the main method.
 * Here, the order of what is to be printed is specified.
 * Moreover, the commands lie within a loop that allows 
 * the user to repeat the program as many times as he or 
 * she desires.
 * 
 * ReportDiver calles upon the class RaceReport to print
 * data that has been collecten in the class Race.
 *
 * @author (Krystle S Levin)
 * @version (November 24th 2017)
 */
public class ReportDriver
{
    public static void main(String[] args){
        boolean anotherRace= true;
        //allows for repitition until user specifies otherwise
        while (anotherRace==true){
            RaceReport print=new RaceReport();
            print.newRace();  //askes user to input 3 race times
            print.placement();  //prints sorted placement
            print.ties();       //printsout any ties that may be present
            print.stats();      //prints our average and range of race times
            
            System.out.println("**************************************");
            //this just creates a nice division between races in the terminal window
            
            anotherRace=print.moreRaces();//asks user if they want to run another race
            System.out.println();    
        }
        System.out.println("Thank you for attending the races.");//end of program
    }
}
